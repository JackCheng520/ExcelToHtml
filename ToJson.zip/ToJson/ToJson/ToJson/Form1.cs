﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Xml;

namespace ToJson
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private DataTable dt;
        private string path;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Application.DoEvents();
                openFileDialog1.Filter = "Excel XLSX|*.xlsx|Excel2007|*.xls";
                openFileDialog1.ShowDialog();
                textBox1.Text = openFileDialog1.FileName;
                comboBox1.DataSource = GetExcelSheets(openFileDialog1.FileName);
                comboBox1.DisplayMember = "TABLE_NAME";
                comboBox1.ValueMember = "TABLE_NAME";
                string fileName = openFileDialog1.FileName;
                path = fileName.Substring(0, fileName.LastIndexOf('\\')+1);
                InitData();
                button2.Enabled = true;
                //button2_Click(null,null);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }
       
        public  DataSet GetExcelToDataTableBySheet(string FileFullPath, string SheetName)
        {
            string strConn = GetConStr(FileFullPath);
            OleDbConnection conn = new OleDbConnection(strConn);
            conn.Open();
            DataSet ds = new DataSet();
            OleDbDataAdapter odda = new OleDbDataAdapter(string.Format("SELECT * FROM [{0}]", SheetName), conn); 
            odda.Fill(ds, SheetName);
            conn.Close();
            return ds;
        }
        public  DataTable GetExcelSheets(string FileFullPath)
        {
            string strConn = GetConStr(FileFullPath);
            OleDbConnection conn = new OleDbConnection(strConn);
            conn.Open();
            // 得到包含数据架构的数据表
            DataTable dt = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            conn.Close();
            return dt;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Application.DoEvents();
            
            string result = ConvertDataTableToXML(dt);
            richTextBox1.Text = result;
            StreamWriter sw = new StreamWriter(path + comboBox1.Text.Replace("$","")+".xml", false, Encoding.UTF8);
            sw.Write(richTextBox1.Text);
            sw.Close();
            sw.Dispose();
            System.Diagnostics.Process.Start(path);
            //MessageBox.Show("保存xml成功！ 路径：" + path);
        }

        private string ConvertDataTableToXML(DataTable xmlDS)
        {
            XmlTextWriter writer = null;
            try
            {
                StringBuilder strXml = new StringBuilder();
                for (int i = 0; i < xmlDS.Rows.Count; i++)
                {
                    if (string.IsNullOrEmpty(xmlDS.Rows[i][0].ToString()))
                        continue;
                    strXml.AppendLine("<TextKey name=\"" + xmlDS.Rows[i][0] + "\">");
                    strXml.AppendLine("<CN>" + xmlDS.Rows[i][1] + "</CN>");
                    //strXml.AppendLine("<EN>" + xmlDS.Rows[i][2] + "</EN>");
                    strXml.AppendLine("</TextKey>");
                }

                return strXml.ToString();
            }
            catch
            {
                return String.Empty;
            }
            finally
            {
                if (writer != null) writer.Close();
            }
        } 


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            InitData();
        }
        private void InitData()
        {
            string str = comboBox1.Text;
            if (str.Equals("System.Data.DataRowView"))
                return;
            DataSet ds = GetExcelToDataTableBySheet(textBox1.Text, comboBox1.Text);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;

            string result = ConvertDataTableToXML(dt);
            richTextBox1.Text = result;
        }
        public string GetConStr(string FileFullPath)
        {
            string strConn = "Provider=Microsoft.Ace.OleDb.12.0;" + "data source=" + FileFullPath + ";Extended Properties='Excel 12.0; HDR=YES; IMEX=1'"; //此連接可以操作.xls與.xlsx文件HDR=YES第一行为列名
            if (checkBox1.Checked)
            {
                strConn = "Provider=Microsoft.Jet.OleDb.4.0;" + "data source=" + FileFullPath + ";Extended Properties='Excel 8.0; HDR=YES; IMEX=1'"; //此連接只能操作Excel2007之前(.xls)文件
            }
            return strConn;
        }

       
       
    }
}
